package com.practicaListas.models;

public class Familia_Generador {
    private String descripcion;
    private Integer id;
    private Integer id_Familia;
    private Integer id_Generador;

    public String getDescripcion() {
        return this.descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId_Familia() {
        return this.id_Familia;
    }

    public void setId_Familia(Integer id_Familia) {
        this.id_Familia = id_Familia;
    }

    public Integer getId_Generador() {
        return this.id_Generador;
    }

    public void setId_Generador(Integer id_Generador) {
        this.id_Generador = id_Generador;
    }

}
